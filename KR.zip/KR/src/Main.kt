import kotlinx.coroutines.*

suspend fun main() {
    var ListSt =  mutableListOf<String>()
    var student = Student()
    GlobalScope.launch{
        while (true){
            student.PrintCount(ListSt)
        }
    }
    println("Записать ученика?")
    while (readln() == "да"){

        println("Введите имя ученика")
        val name = readln()
        println("Введите Фамилия ученика")
        val surname = readln()
        println("Введите Отчество ученика")
        val patronymic = readln()
        println("Введите Пол ученика")
        val sex = readln()
        println("Введите Группу ученика")
        val group = readln()
        println("Введите Дату рождения ученика")
        val birthdate = readln()
        println("Введите Рост ученика")
        val height = readln().toDouble()
        println("Введите Вес ученика")
        val weight = readln().toDouble()
        println("Введите спорт которым занимается ученик")
        val sport = readln()
        student.AddStudent(name,surname,patronymic, sex, group, birthdate, height, weight, sport)
        student.PrintInfo(student)
        val ST = ("$name, $surname, $patronymic, $sex\n" +
                "$group, $birthdate\n" +
                "$height, $weight\n" +
                "$sport")
        ListSt.add(ST)

        println("Записать ученика?")
    }
    println("О каком ученике хотите узнать?")
    val na = readln().toInt()
    if (na < ListSt.count()){
        println(ListSt[na])
    }
    println("Хотите вывести всю информацию о студентах?")
    if (readln() == "да"){
        student.PrintAllInfo(ListSt)
    }
}