import kotlinx.coroutines.*
class Student : StudentAbs() {

    override  var name: String = ""
    override var surname: String = ""
    override var patronymic: String = ""
    override var sex: String = ""
    override var group: String = ""
    override var birthdate: String = ""
    override var height: Double = 0.0
    override var weight: Double = 0.0
    override var sport: String = ""

    suspend fun AddStudent(name:String, surname:String, patronymic:String, sex:String, group:String, birthdate:String, height:Double, weight:Double, sport:String){
        this.name = name
        this.surname = surname
        this.patronymic = patronymic
        this.sex = sex
        this.group = group
        this.birthdate = birthdate
        this.height = height
        this.weight = weight
        this.sport = sport
        println("Подождите, идёт запись студента")
        delay(400L)
    }
    override fun PrintInfo(student:Student) {
        println("$name, $surname, $patronymic, $sex\n" +
                "$group, $birthdate\n" +
                "$height, $weight\n" +
                "$sport")
    }
    suspend fun PrintCount(ListSt : MutableList<String>){
        println("На данный момент ${ListSt.count()} студентов записано")
        delay(15000L)
    }
}