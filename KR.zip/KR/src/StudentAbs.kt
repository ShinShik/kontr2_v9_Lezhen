abstract class StudentAbs : StudentInterface {
    override var name: String = ""
    override var surname: String = ""
    override var patronymic: String = ""
    override var sex: String = ""
    override var group: String = ""
    override var birthdate: String = ""
    override var height: Double = 0.0
    override var weight: Double = 0.0
    override var sport: String = ""

    override fun PrintInfo(student:Student) {
    }
    fun PrintAllInfo(list: MutableList<String>) {
        for (n in list){
            println(n)
        }
    }
}