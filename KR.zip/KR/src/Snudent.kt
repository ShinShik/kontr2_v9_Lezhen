

interface StudentInterface {
    val name:String
    val surname:String
    val patronymic:String
    val sex:String
    val group:String
    val birthdate:String
    val height:Double
    val weight:Double
    val sport:String
    fun PrintInfo(student:Student)
}